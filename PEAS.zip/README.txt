Run PEAS by double clicking PEAS.jar or running:
java -jar PEAS.jar